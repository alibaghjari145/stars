#include <stdio.h>
#include <stdlib.h>

int main()
{
 int lineNum;
 int starsNum;
 scanf("%d",&lineNum);
 for(lineNum;lineNum>=1;lineNum=lineNum-1){
    for(starsNum=1;starsNum<=lineNum;starsNum++){
        printf("*");
    }
    printf("\n");
 }
}
